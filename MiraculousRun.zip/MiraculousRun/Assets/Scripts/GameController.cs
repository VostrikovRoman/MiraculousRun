using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public bool move = true;
    public GameObject GameScene;
    public GameObject UI;
    public GameObject Menu;
    public GameObject Settings;
    public GameObject Skins;
    public GameObject Scores;
    public GameObject GameOver;
    public GameObject Background;

    public bool startGame = false;

    public GameObject Player;
    public GameObject Enemy;

    public Health gameAgain;
    public Energy gameAgain2;

    
    public void BackToMenu()
    {
        GameScene.SetActive(false);
        GameOver.SetActive(false);
        UI.SetActive(false);
        //Skins.SetActive(false);
        Settings.SetActive(false);
        //Scores.SetActive(false);
        Menu.SetActive(true);
        Background.SetActive(true);
    }
    public void ToMenu()
    {
        Settings.SetActive(false);
        Skins.SetActive(false);
        Scores.SetActive(false);
        Menu.SetActive(true);
    }
    public void StartGame()
    {
        GameScene.SetActive(true);
        UI.SetActive(true);
        Menu.SetActive(false);
        Background.SetActive(false);
        GameOver.SetActive(false);
        move = true;
        gameAgain.GameAgain();
        gameAgain2.GameAgain();
    }

    public void ToSettings()
    {
        Menu.SetActive(false);
        Settings.SetActive(true);
    }

    public void ToSkins()
    {
        Menu.SetActive(false);
        Skins.SetActive(true);
    }
    public void ToScores()
    {
        Menu.SetActive(false);
        Scores.SetActive(true);
    }
}
